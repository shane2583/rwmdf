# -*- coding: utf-8 -*-
""" asammdf version module """

__version__ = "5.4.1"
