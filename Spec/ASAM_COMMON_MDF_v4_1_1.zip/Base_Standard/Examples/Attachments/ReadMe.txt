Attachments in MDF 4.x
======================

An attachment can be a "link" to an external file, or it can be embedded within the MF4 file.

For embedded attachments, they also can be compressed using the GZIP algorithm.

The examples show the attachments for the following three files

- this file (one folder above the MF4 file)
- a ZIP archive containing this file (in same folder as MF4 file)
- an HTML file (in a sub folder)
