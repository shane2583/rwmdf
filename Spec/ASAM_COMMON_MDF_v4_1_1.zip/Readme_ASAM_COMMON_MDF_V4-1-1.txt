/*************************************************************** 
*** ASAM COMMON MDF                                          *** 
*** Version:  4.1.1                                          *** 
*** Date:     September, 30 2014                             *** 
***************************************************************/

The deliverable of ASAM COMMON MDF version 4.1.1 includes:

Directory Base_Standard

       - ASAM_COMMON_MDF_BS_V4-1-1.pdf
       - XML schema files for meta data description (Schemas/*.xsd)
       - Example MF4 files for different use cases (Examples/*.mf4)

Directory Associated_Standards

       - ASAM_COMMON_MDF_BusLogging_AS_V1-0-1.pdf
       - ASAM_COMMON_MDF_Measurement_Environment_AS_V1-0-0
       - ASAM_COMMON_MDF_Naming_Of_Channels_And_Channel_Groups_AS_V1-0-0
	   - ASAM_COMMON_MDF_ClassificationResults_AS_V1-0-0
